/* ============================================================================
 * D Y N I B E X - QuickComputation of Zonotope from Dynibex
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Sept 30, 2025
 * Modified    : Sept 30, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include <iostream>
#include <list>
#include "libqhullcpp/Qhull.h"
#include "libqhullcpp/QhullFacetList.h"
#include "libqhullcpp/QhullVertexSet.h"

using namespace orgQhull;
using namespace ibex;
using namespace std;

struct PointCloud
{
  std::vector<vector<double>> cloud;
  std::vector<std::pair<std::vector<double>, std::vector<int>>> cloud_origin; // point + la combinaison qui le calcule
};


struct AffineDecomp {
    double center;
    std::vector<std::pair<int,double>> coeffs;
    Interval garbage;
};

// calcule du convexhull en utilisant Qhull (Quick Hull) install: sudo apt-get install qhull-bin libqhull-dev
std::vector<std::vector<double>> computeConvexHullVertices(const std::vector<std::vector<double>>& point_cloud) 
{
    if (point_cloud.empty()) {
        throw std::runtime_error("Point cloud vide !");
    }

    int dim = point_cloud[0].size();
    int numPoints = point_cloud.size();

    // Vérification
    for (const auto& p : point_cloud) {
        if ((int)p.size() != dim) {
            throw std::runtime_error("Tous les points doivent avoir la même dimension !");
        }
    }

    // Aplatir le tableau pour Qhull
    std::vector<double> flatPoints;
    flatPoints.reserve(numPoints * dim);
    for (const auto& p : point_cloud) {
        flatPoints.insert(flatPoints.end(), p.begin(), p.end());
    }

    // Exécuter Qhull
    Qhull qh;
    qh.runQhull("convex_hull", dim, numPoints, flatPoints.data(), "Qt");

    // Extraire les sommets
    std::vector<std::vector<double>> hullVertices;
    for (auto v = qh.vertexList().begin(); v != qh.vertexList().end(); ++v) {
        const double* coords = v->point().coordinates();
        hullVertices.emplace_back(coords, coords + dim);
    }

    return hullVertices;
}


void printAffineDecomp(const AffineDecomp& a) {
    std::cout << a.center;
    for (auto& c : a.coeffs) {
        if (c.second >= 0) std::cout << " + " << c.second << "*eps_" << c.first;
        else std::cout << " - " << -c.second << "*eps_" << c.first;
    }
    std::cout << " + [" << a.garbage.lb() << ", " << a.garbage.ub() << "]";
}

void printAffineVector(const std::vector<AffineDecomp>& vec) {
    std::cout << "AffineDecomp vector (" << vec.size() << " elements):\n";
    for (size_t i = 0; i < vec.size(); ++i) {
        std::cout << "  [" << i << "] ";
        printAffineDecomp(vec[i]);
        std::cout << "\n";
    }
}

// Fabrique une affine2 avec un centre et des coefficients eps_i pour Ibex avec fAFFullI
Affine2Main<AF_fAFFullI> make_affine(
    double center,
    const std::vector<std::pair<int,double>>& coeffs,
    Interval garbage = Interval(0.0)) 
{
    Affine2Main<AF_fAFFullI> a(center);
    std::list<std::pair<int,double>> rays;
    for (auto& c : coeffs) {
        rays.push_back(c);
    }
    a.initialize(center, rays, garbage);
    return a;
}

// transforme une Affine de dynibex fAFFullI dans mon format
AffineDecomp decompose_affine(const Affine2Main<AF_fAFFullI>& a) {
    AffineDecomp dec;
    dec.center = a.val(0);
    dec.garbage = Interval(-a.err(), a.err()); // l’erreur est centrée

    if (a.is_actif()) {
        for (const auto& r : a.get_rays()) {
            dec.coeffs.push_back({r.first, r.second});
        }
    } else {
        std::cout << "Prog: Affine2Main form not Activate" << std::endl;
    }

    return dec;
}

///on crée la liste des combinaisons possible de générateur
std::vector<std::vector<int>> generate_sign_combinations(int N) {
    std::vector<std::vector<int>> combos;
    int total = 1 << N; // 2^N combinaisons

    combos.reserve(total); 

    for (int mask = 0; mask < total; ++mask) {
        std::vector<int> signs(N);
        for (int j = 0; j < N; ++j) {
            // bit j du mask → signe
            signs[j] = (mask & (1 << j)) ? +1 : -1;
        }
        combos.push_back(signs);
    }
    return combos;
}

//fonction d'addition de vecteur
std::vector<double> add_vector(const std::vector<double>& v1, const std::vector<double>& v2){
  
    std::vector<double> result;
    if (v1.size()!= v2.size())
    {
      std::cout<<"ERROR: WRONG SIZE"<<std::endl;
      return result;
    }

    for (size_t i = 0; i < v1.size(); i++)
    {
      result.push_back(v1[i] + v2[i]);
    }
    
    return result;
}

//fonction de multiplication de vecteur
std::vector<double> gain_vector(const std::vector<double>& v1, const int& K){
  
    std::vector<double> result;
    for (size_t i = 0; i < v1.size(); i++)
    {
      result.push_back(K*v1[i]);
    }
    return result;
}

// transforme une vecteur d'Affine de dynibex fAFFullI dans un vecteur de mon format
std::vector<AffineDecomp> DyniAff2Vec(const Affine2Vector& aff_vec){

  std::vector<AffineDecomp> result;

  for (size_t i = 0; i < aff_vec.size(); i++)
  {
    result.push_back(decompose_affine(aff_vec[i]));
  }
    printAffineVector(result);
  return result;
}

//on récupère le vecteur du centre d'un vecteur d'affine
std::vector<double> get_center_aff2vec(const std::vector<AffineDecomp>& affine_vector){
  
  std::vector<double> result;
  for (size_t i = 0; i < affine_vector.size(); i++)
  {
    result.push_back(affine_vector[i].center);
  }
  return result;
}

//on construit les générateurs à partir de la forme affine
std::vector<std::vector<double>> build_generators(const std::vector<AffineDecomp>& aff_vec) {
    const int dim_vec = aff_vec.size();
    std::vector<std::vector<double>> generators;
    std::vector<int> noise_symbols;
    
    int max = 0; //nombre de termes de bruits

    // chercher l'indice max de bruit utilisé
    for (const auto& a : aff_vec) {
        for (auto& kv : a.coeffs) {
            if (kv.first > max){
              max = kv.first;
            noise_symbols.push_back(max); //on fait une liste avec les numéros de symbole de bruit par ordre croissant
            }
        }
    }
    std::cout<<"Known generator : ";
    for (size_t i = 0; i < noise_symbols.size(); i++)
    {
       std::cout<<"eps_"<<noise_symbols[i]<<" ; ";
    }
    std::cout<<std::endl;

    for (size_t i = 0; i < noise_symbols.size(); i++)
    {
      std::vector<double> temp(dim_vec, 0.0);
      for (size_t j = 0; j < dim_vec; j++)
      {
          //on se balade dans toute les formes affines pour trouver les correspondances pour construire les générateurs
       for (size_t k = 0; k < aff_vec[j].coeffs.size(); k++)
       {
        if (aff_vec[j].coeffs[k].first==noise_symbols[i])
        {
          temp[j]=aff_vec[j].coeffs[k].second; //correspondance trouvée on passe à la dimension d'après
          break;
        }
       }
      }
      generators.push_back(temp);
    }
   
return generators;
}

// c'est la fonction qui calcule les combinaisons possible de génerateur
PointCloud candidate_vertices(const Affine2Vector& aff_vec){

PointCloud result;
const double size_vec = aff_vec.size();
std::vector<AffineDecomp> affine_vector = DyniAff2Vec(aff_vec);
//mettre le centre -fait
std::vector<double> center_vec = get_center_aff2vec(affine_vector);
std::vector<std::vector<double>> generators = build_generators(affine_vector); //on construit les generateurs
std::vector<std::vector<int>> combos = generate_sign_combinations(generators.size()); //on construit les combos de vecteurs

for (size_t i = 0; i < combos.size(); i++)
{
  std::vector<double> temp(size_vec,0.0);
  for (size_t j = 0; j < combos[i].size(); j++)
  {
    temp = add_vector(gain_vector(generators[j], combos[i][j]), temp);
  }
  auto computed_point = add_vector(temp, center_vec);//on rajoute le centre
  result.cloud.push_back(computed_point);
  result.cloud_origin.push_back(make_pair(computed_point, combos[i]));
}
  return result;
}

PointCloud Affine2Vertices(const Affine2Vector& aff_vec){

    PointCloud result;
    PointCloud comp_cl = candidate_vertices(aff_vec);
    result.cloud = computeConvexHullVertices(comp_cl.cloud);

    return result;
}

int main() {

    AF_fAFFullI::setAffineNoiseNumber(2500); //pour la simu entre chaque pas de temps

    // x1 = 4.0 + 0.10 eps_1 + 0.10 eps_2 + 0.10 eps_3 + 0.25 eps_4
    auto x1 = make_affine(4.0, {{1, 0.10}, {2, 0.10},{3, 0.1},{4, 0.25}});

    // x2 = 2 + -0.08 eps_1 + 0.15 eps_2 + 0.05 eps_3
    auto x2 = make_affine(2.0, {{1, -0.08}, {2, 0.15},{3, 0.05}});

    Affine2Vector yinit_aff(2);  // vector of size 2
    yinit_aff[0] = x1;
    yinit_aff[1] = x2;

    auto vertices = Affine2Vertices(yinit_aff);

    //affichage dans le terminal
    auto hull = vertices.cloud;

    std::cout << "Sommets de l'enveloppe convexe :" << std::endl;
    for (const auto& vertex : hull) {
        for (size_t i = 0; i < vertex.size(); i++) {
            std::cout << vertex[i] << (i+1 < vertex.size() ? " " : "");
        }
        std::cout << std::endl;
    }

  /*//exemple de simulation 
    const int n= 2; ///nombre d'état dans le système différentiel
    Variable y(n);

      double tsimu=2.0;
      //---------------simulation--------------------
      Function ydot = Function(y,Return(y[1], 0.2*(1-sqr(y[0]))*y[1]-y[0])); //van der pol

      
      ivp_ode problem = ivp_ode(ydot,0.0,yinit_aff);    
      simulation simu = simulation(&problem,tsimu,RK4,1e-6, 1e-5);

      simu.run_simulation();

      AF_fAFFullI::setAffineNoiseNumber(4);

      Affine2Vector result = simu.get_last_aff();

      result.compact(); ///on récupère un nombre fini de noise number (4)

          // print
    std::cout << "Y[0] = " << result[0] << std::endl;
    std::cout << "Y[1] = " << result[1] << std::endl;
  
  std::ofstream sim_result;
  sim_result.open("sim_result_aff.txt");
  sim_result<<result[0] <<" ; "<< result[1] <<std::endl;
  sim_result.close();

    std::ofstream sim_init;
  sim_init.open("sim_init_aff.txt");
  sim_init<<yinit_aff[0] <<" ; "<< yinit_aff[1] <<std::endl;
  sim_init.close();

  ///ATTENTION IL PEUT Y AVOIR DES ERREURS DE CALCUL FLOTANT LORS DE LA CRÉATION DU HULL TODO CF METHODE SUR DOCU QHull

   auto vertices2 = Affine2Vertices(result);

    //affichage dans le terminal
    auto hull2 = vertices2.cloud;

   std::cout << "Sommets de l'enveloppe convexe :" << std::endl;
    for (const auto& vertex : hull2) {
        for (size_t i = 0; i < vertex.size(); i++) {
            std::cout << vertex[i] << (i+1 < vertex.size() ? " " : "");
        }
        std::cout << std::endl;
    }
    */

    return 0;
}