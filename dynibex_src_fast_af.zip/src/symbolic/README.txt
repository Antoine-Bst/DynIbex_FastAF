Ce dossier contient l'ensemble des fichiers à ajouter dans le répertoire symbolic d'ibex.
Les fichiers précédents sont à écraser.
