To run the test program:

java -Djava.library.path=[ibex-path]/lib Test

