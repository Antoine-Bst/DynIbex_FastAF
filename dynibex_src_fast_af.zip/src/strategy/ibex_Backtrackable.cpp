//============================================================================
//                                  I B E X                                   
// File        : ibex_Backtrackable.cpp
// Author      : Gilles Chabert
// Copyright   : Ecole des Mines de Nantes (France)
// License     : See the LICENSE file
// Created     : May 11, 2012
// Last Update : May 11, 2012
//============================================================================

#include "ibex_Backtrackable.h"

namespace ibex {

} // end namespace ibex
